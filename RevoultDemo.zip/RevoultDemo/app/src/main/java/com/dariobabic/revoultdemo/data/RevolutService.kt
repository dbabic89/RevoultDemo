package com.dariobabic.revoultdemo.data

import io.reactivex.Observable
import retrofit2.http.GET
import retrofit2.http.Query

interface RevolutService {
    @GET("latest")
    fun getLatestCurrencyRates(@Query("base") baseCurrencyCode: String): Observable<RevolutBaseResponse>
}