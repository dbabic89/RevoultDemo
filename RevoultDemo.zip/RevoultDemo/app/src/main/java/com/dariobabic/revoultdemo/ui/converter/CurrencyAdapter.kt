package com.dariobabic.revoultdemo.ui.converter

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dariobabic.revoultdemo.domain.Currency
import com.dariobabic.revoultdemo.R
import com.dariobabic.revoultdemo.utils.ResourcesUtils

class CurrencyAdapter(private val listener: SymbolListener) :
    RecyclerView.Adapter<CurrencyViewHolder>() {

    var items: ArrayList<Currency>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CurrencyViewHolder {
        val context = parent.context
        val view = LayoutInflater.from(context).inflate(viewType, parent, false)
        return CurrencyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items?.size ?: 0
    }

    override fun onBindViewHolder(holder: CurrencyViewHolder, position: Int) {
        val currency = items?.get(position) ?: return
        val symbol = currency.symbol
        holder.imageCurrencyFlag.setImageResource(
            ResourcesUtils.getCurrencyFlagId(
                holder.currencyValue.context,
                symbol
            )
        )
        holder.textCurrencyCode.text = symbol
        holder.textCurrencyName.setText(
            ResourcesUtils.getCurrencyNameId(
                holder.currencyValue.context,
                symbol
            )
        )

//        holder.currencyValue.setText(String.format("%.2f", currency.value))
        holder.currencyValue.hint = String.format("%.2f", currency.value)

        holder.currencyValue.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {

            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
//                val string = p0.toString()
//                try {
//                    val toDouble = string.toDouble()
//                    listener.onValueChanged(toDouble)
//                } catch (e : NumberFormatException) {
//
//                }
                listener.onValueChanged(p0.toString().toDouble())
            }
        })
        holder.view.setOnClickListener {
            listener.onSymbolChanged(symbol)
//            items?.removeAt(position).also {
//                items?.add(0, currency)
//            }
//            notifyDataSetChanged()
            moveItem(position)
        }

    }

    override fun getItemViewType(position: Int): Int {
        return R.layout.item_rate
    }

    fun moveItem(fromPosition: Int) {
        if (fromPosition == 0) return

        val movingItem = items?.removeAt(fromPosition) ?: return
        items?.add(0, movingItem)

        notifyItemMoved(fromPosition, 0)
    }
}