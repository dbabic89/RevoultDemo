package com.dariobabic.revoultdemo.ui.converter

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dariobabic.revoultdemo.*
import com.dariobabic.revoultdemo.data.RevolutBaseResponse
import com.dariobabic.revoultdemo.data.RevolutService
import com.dariobabic.revoultdemo.domain.Currency
import com.dariobabic.revoultdemo.utils.Constants
import com.google.gson.Gson
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_converter.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class ConverterFragment : Fragment() {

    var baseCurrentSymbol = "EUR"
    var currentValue = 100.0

    val listener = object : SymbolListener {

        override fun onSymbolChanged(symbol: String) {
            baseCurrentSymbol = symbol
            recyclerView.smoothScrollToPosition(0)
        }

        override fun onValueChanged(value: Double) {
            currentValue = value
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_converter, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val currencyAdapter = CurrencyAdapter(listener)
        recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        recyclerView.adapter = currencyAdapter

        val httpLoggingInterceptor = HttpLoggingInterceptor(object : HttpLoggingInterceptor.Logger {
            override fun log(message: String) {
                Log.i("REVOLUT_SERVICE", message)
            }
        })
        httpLoggingInterceptor.level = HttpLoggingInterceptor.Level.BASIC

        val okHttpClient =
            OkHttpClient().newBuilder().addInterceptor(httpLoggingInterceptor).build()

        val retrofit =
            Retrofit.Builder().baseUrl(Constants.REVOLUT_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(Gson()))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(okHttpClient).build()
                .create(RevolutService::class.java)

        Observable
            .interval(1000, TimeUnit.MILLISECONDS, Schedulers.io())
            .flatMap {
                retrofit.getLatestCurrencyRates(baseCurrentSymbol)
            }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(object : Observer<RevolutBaseResponse> {
                override fun onComplete() {

                }

                override fun onNext(response: RevolutBaseResponse) {
                    var items = currencyAdapter.items
                    if (items.isNullOrEmpty()) {
                        items = format(response)
                    } else {
                        items.forEach {
                            val symbol = it.symbol
                            var value = currentValue
                            response.rates?.forEach {
                                if (symbol == it.key) {
                                    value = it.value * currentValue
                                }
                            }
                            it.value = value
                        }
                    }
                    currencyAdapter.items = items
                    currencyAdapter.notifyDataSetChanged()
                }

                override fun onSubscribe(d: Disposable) {

                }

                override fun onError(e: Throwable) {
                    val localizedMessage = e.localizedMessage ?: return
                    Log.i("REVOLUT_SERVICE", localizedMessage)
                }
            })
    }

    fun format(response: RevolutBaseResponse): ArrayList<Currency> {
        val list = ArrayList<Currency>()
        val base = response.base ?: ""
        list.add(Currency(base, 100.00))
        val rates = response.rates
        rates?.forEach {
            list.add(Currency(it.key, it.value))
        }
        return list
    }

}
