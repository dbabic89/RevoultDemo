package com.dariobabic.revoultdemo

import android.app.Application
import com.akaita.java.rxjava2debug.RxJava2Debug

class RevolutDemoApplication: Application() {

    override fun onCreate() {
        super.onCreate()
        RxJava2Debug.enableRxJava2AssemblyTracking()
    }
}