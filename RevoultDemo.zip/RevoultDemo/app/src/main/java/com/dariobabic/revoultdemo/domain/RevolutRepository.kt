package com.dariobabic.revoultdemo.domain

import com.dariobabic.revoultdemo.data.RevolutBaseResponse
import com.dariobabic.revoultdemo.data.RevolutService
import io.reactivex.Observable

class RevolutRepository(private val revolutService: RevolutService) {

    fun getLatestCurrenyRates(baseRate: String): Observable<RevolutBaseResponse> {
        return revolutService.getLatestCurrencyRates(baseRate)
    }
}