package com.dariobabic.revoultdemo.domain

data class Currency(val symbol: String, var value: Double)