package com.dariobabic.revoultdemo.ui.converter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_rate.view.*

class CurrencyViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
    val imageCurrencyFlag = view.imageCurrencyFlag
    val textCurrencyCode = view.textCurrencyCode
    val textCurrencyName = view.textCurrencyName
    val currencyValue = view.currencyValue
}