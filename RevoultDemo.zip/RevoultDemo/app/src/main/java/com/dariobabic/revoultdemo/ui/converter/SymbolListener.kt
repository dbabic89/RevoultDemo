package com.dariobabic.revoultdemo.ui.converter

interface SymbolListener {

    fun onSymbolChanged(symbol: String)

    fun onValueChanged(value: Double)
}